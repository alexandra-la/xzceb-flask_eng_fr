import unittest
from ibm_watson import LanguageTranslatorV3
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
import os
from dotenv import load_dotenv

load_dotenv()

apikey = os.environ['apikey']
url = os.environ['url']

authenticator1 = IAMAuthenticator(apikey)
language_translator = LanguageTranslatorV3(
    version='2018-05-01',
    authenticator= authenticator1
)

language_translator.set_service_url('https://api.us-south.language-translator.watson.cloud.ibm.com/instances/4c5515b4-23a3-496f-99a9-439d339e79bb')

languages = language_translator.list_languages().get_result()

def englishToFrenchtest(englishText):
    frenchText = language_translator.translate(
        text= englishText, 
        model_id='en-fr').get_result()
    print(frenchText)
    return frenchText

def frenchToEnglishtest(frenchText):
    englishText = language_translator.translate(
        text= frenchText,
        model_id='fr-en').get_result()
    return englishText

class testEnglishMethods(unittest.TestCase):

    def test_null_english(self):
        self.assertEqual(englishToFrenchtest(''), '')
    def test_hello_english(self):
        self.assertEqual(englishToFrenchtest('Hello'), 'Bonjour')

class frenchMethodTests(unittest.TestCase):

    def test_null_french(self):
        self.assertEqual(frenchToEnglishtest(''), '')
    def test_hello_french(self):
        self.assertEqual(frenchToEnglishtest('Bonjour'), 'Hello')

    unittest.main()
